---
name: Nova Sync Electric
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#aad600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#cfcc3c'
  on-secondary: '#333200'
  secondary-container: '#a09d00'
  on-secondary-container: '#343200'
  tertiary: '#ffffff'
  on-tertiary: '#16343f'
  tertiary-container: '#c8e7f6'
  on-tertiary-container: '#4c6875'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#aad600'
  on-primary-fixed: '#161f00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#ece856'
  secondary-fixed-dim: '#cfcc3c'
  on-secondary-fixed: '#1d1d00'
  on-secondary-fixed-variant: '#4b4900'
  tertiary-fixed: '#c8e7f6'
  tertiary-fixed-dim: '#adcbda'
  on-tertiary-fixed: '#001f29'
  on-tertiary-fixed-variant: '#2e4b57'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 4.5rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.05em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '700'
    lineHeight: '1.5'
    letterSpacing: 0.1em
  body-lg:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Manrope
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.5'
  label-xs:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '900'
    lineHeight: '1'
    letterSpacing: 0.4em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 80rem
  section-padding: 6rem
  gutter: 2rem
  stack-sm: 1rem
  stack-md: 2rem
  stack-lg: 4rem
---

## Brand & Style
Nova Sync embodies a "High-Octane Professional" personality, blending the raw energy of the grooming industry with technical, data-driven precision. The visual style is a fusion of **Dark-Mode Minimalism** and **Glassmorphism**, punctuated by aggressive, high-contrast accents.

The brand targets elite salon owners who value both aesthetic flair and operational efficiency. The UI should evoke a sense of "Electric Precision"—it feels premium, fast, and authoritative. Key visual motifs include lime-green glows against deep blacks, large-scale typography for clear messaging, and semi-transparent layers that provide depth without clutter.

## Colors
The palette is built on a "Neon-on-Onyx" foundation. The primary **Electric Lime** (#CAFD00) is used sparingly but powerfully for calls-to-action and critical data visualizations. 

- **Primary:** Electric Lime for high-impact interactions.
- **Surface Strategy:** We use a hierarchy of darks. The base background is a pure charcoal black, while containers use a slightly lighter zinc or obsidian tint to create separation.
- **Glass Effects:** Navigation and floating panels use a backdrop blur with 60% opacity to maintain context of the background gradients.
- **Accents:** Neon glows and pulse animations are used to draw the eye to strategic milestones and active statuses.

## Typography
The typography system uses a dual-font approach to balance impact with readability.
- **Plus Jakarta Sans** is the "voice" of the brand, used for headlines and all-caps labels. It features heavy weights (700-800) and tight tracking to create a modern, high-fashion editorial feel.
- **Manrope** serves as the functional workhorse, providing clarity for body text, descriptions, and user inputs. 
- **Character:** Use "Text Glow" effects (soft lime drop shadows) on specific keywords within headlines to emphasize the "Electric" brand pillar.

## Layout & Spacing
The layout follows a **Fixed-Width Grid** system for desktop, centered with a maximum width of 1280px (80rem). 

- **Sectioning:** Large vertical breathing room (6rem+) between major sections ensures the high-contrast elements don't overwhelm the user.
- **Rhythm:** An 8px base unit is used for component-level spacing. 
- **Asymmetry:** Occasional rotations (e.g., 2-degree tilts on hero images) break the rigid grid to add a sense of dynamic movement.

## Elevation & Depth
Depth is created through **Luminance and Blur** rather than traditional shadows.
- **Z-Index 0:** Deep black background with radial lime gradients (#CAFD00 at 5-10% opacity) to create atmospheric light.
- **Z-Index 1:** Surface containers using `#131313` with very subtle `outline-variant/10` borders.
- **Z-Index 2:** Floating elements (Nav, CTAs) utilizing `backdrop-filter: blur(20px)` and semi-transparent backgrounds.
- **Interactive Depth:** Hovering over cards should trigger a border-color transition from neutral to `primary-fixed/30` and a subtle lime outer glow.

## Shapes
The shape language is "Optimized Organic." While the core containers are rounded for a modern feel, the radius values are generous:
- **Base Components:** 0.75rem (Buttons, small cards).
- **Major Containers:** 1rem to 1.5rem (Pricing cards, team photos).
- **Hero/CTA Sections:** 2rem to 3rem (Large nested containers).
- **Special Elements:** Full pill shapes for badges and status indicators.

## Components
- **Primary Buttons:** High-contrast lime background with bold black text. They feature a `scale-95` active state and a vibrant outer glow on hover.
- **Ghost Buttons:** Transparent background with a `0.3` opacity border. On hover, they fill with white or lime.
- **Pricing Cards:** The "Popular" card is differentiated by a 2px solid lime border and a vertical offset (-1rem) to break the horizon line.
- **Badges/Chips:** Tiny all-caps text with high letter-spacing, often containing a pulsing dot icon to signify "Live" or "Elite" status.
- **Testimonials:** Use a vertical border accent (4px lime stripe) on the left side to anchor the quote.
- **Input Fields (Systemic):** Dark backgrounds, subtle outlines that illuminate to lime on focus.